#ifndef DECODE_H
#define DECODE_H

#define MAGICSTRING "#*"

//sturcture to perfrom decoding
typedef struct _DecodeInfo													
{
    /* Source Image info */
    char *src_image_fname;
    FILE *fptr_src_image;

    /* Secret File Info */
    char *secret_fname;
    FILE *fptr_secret;

    char *ext;
    int size;

} DecodeInfo;


//####################DECODING######################################

//Function to do read and validate
void d_read_and_validate_encode_args(char *argv[], DecodeInfo *dinfo);

//Function to open source file
void source_open_files(DecodeInfo *dinfo);

//Function to perfrom all the decoding operations
void do_decoding(DecodeInfo *dinfo);

//Function to decode MAGIC STRING
void decode_magic_string(DecodeInfo *dinfo);

//Function to decode image Bytea to data
void decode_image_to_data(char *arr,int size, DecodeInfo *dinfo);

//Function to decode LSB's of image to byte of data
char decode_LSB_to_byte( DecodeInfo *dinfo);

//Function to decode secret file extnension size
int decode_secret_file_extn_size(DecodeInfo *dinfo);

//Function to decode secret file size
int decode_secret_file_size(DecodeInfo *dinfo);

//Function to decode secret file data
void decode_secret_file_data(DecodeInfo *dinfo);

#endif
