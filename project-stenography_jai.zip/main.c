//Documentation
//Name           : D. Jaya Krishna
//Date           : 20-04-2022
//Description    : LSB Steganography
//Input          :
//Output         :
//Documentation
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "encode.h"
#include "types.h"

int main(int argc,char *argv[])
{
	struct _EncodeInfo einfo; 
	struct _DecodeInfo dinfo;
	int r;
	if(argc > 1)																			//for only ./a.out as command line argument
	{
		r=check_operation_type(argv[1]);
		if(r)
		{	
			//START OF ENCODING
			if(argc <3)																	//for ./a.out -<coding type>
				printf("Error : Provide atleast 1 .bmp file and .txt or .c\n\tIn the format=> ./<filename> -e <.bmp file> <.txt file> <.bmp file>\n");
			else if(argc <4)																//for ./a.out -<coding type> <file name>
				printf("Error : Provide atleast 1 .bmp file and .txt or .c each\n\tIn the format=> ./<filename> -e <.bmp file> <.txt file> <.bmp file>\n");
			else			 
			{
				printf("##### IN ENCODING MODE #####\n");
				read_and_validate_encode_args(argv,&einfo);
				open_files(&einfo);
				check_capacity(&einfo);
				do_encoding(&einfo);
			}
			//end of ENCODING
		}
		else																			//DECODING
		{
			//START OF ENCODING
			if(argc <3)																	//for ./a.out -<coding type>
				printf("Error : Provide atleast .bmp file \n\tIn the format=> ./<filename> -e <.bmp file> <.txt file>\n");
			else
			{
				printf("##### IN DECODING MODE #####\n");													
				d_read_and_validate_encode_args(argv,&dinfo);
				source_open_files(&dinfo);
				do_decoding(&dinfo);
			}
			//end of DECODING
		}
	}
	else
		printf("Error:	Provide coding type,atleast 1 .bmp file and .txt or .c\n\tIn the format=> ./<filename> -e <.bmp file> <.txt file> <.bmp file>\n");
	return 0;
}
