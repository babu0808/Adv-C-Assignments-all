//Documentation
//Name           : D. Jaya Krishna
//Date           : 20-04-2022
//Description    : decoding part - lsb steganography
//Input          : 
//Output         :
//Documentation
#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include "encode.h"


char defaultn[20]="decoded";
//Function to read and validate_command line arguments
void d_read_and_validate_encode_args(char *argv[], DecodeInfo *dinfo)
{
	
	printf("***** Read and Validate function in Process *****\n");
	char *checknull;															//a charater pointer to check the file names
	checknull=strstr(argv[2],".bmp");
	if(checknull != NULL)															//if argv[2] is .bmp file
	{
		dinfo->src_image_fname=argv[2];
		if(argv[3] != NULL)
		{
			checknull=strstr(argv[3],".txt");
			if(checknull == NULL)
			{
				checknull=strstr(argv[3],".c");
				if(checknull != NULL)
				{
					dinfo->ext=".c";											//storing output file extension
					dinfo->secret_fname=argv[3];	
				}
				else
				{
					printf("Error : Provide text file with correct extension ( .c or .txt )\n##### DECODING TERMINATED #####\n");
					exit(0);
				}
			}
			else
			{
				dinfo->ext=".txt";												//storing output file extension
				dinfo->secret_fname=argv[3];
			}
		}
		else
		{
			dinfo->ext=NULL;													//storing output file extension as null if user has not provided.
			dinfo->secret_fname=defaultn;
		}
	}
	else																	//if argv[2] is not .bmp file
	{											
		printf("Error : Provide Image file in .bmp format.\n##### DECODING TERMINATED #####\n");
		exit(0);
	}
	printf("***** Read and Validate Successfully *****\n");
}

//Function to open source file
void source_open_files(DecodeInfo *dinfo)
{
	printf("*****Opening required files*****\n");
    	dinfo->fptr_src_image = fopen(dinfo->src_image_fname, "r");										//opening source file in read mode
	if (dinfo->fptr_src_image == NULL)													//validation
	{
	  	perror("fopen");
	    	fprintf(stderr, "ERROR: Unable to open file %s.\n##### DECODING TERMINATED #####\n", dinfo->src_image_fname);
	    	exit(0);
	}
	printf("INFO =>	Opening %s file\n", dinfo->src_image_fname);
}

//Function to decoding MAGIC STRING
void decode_magic_string(DecodeInfo *dinfo)
{
	char *arr=malloc(2);
	decode_image_to_data(arr,2,dinfo);
	if((strstr(arr,MAGICSTRING)) != NULL)													//validating obtained 	magic string
		printf("INFO =>	Magic string is decoded to successfully.\n");
	else
	{
		printf("Error : 	MAGIC_STRING is not matching\n##### DECODING TERMINATED #####\n");
		exit(0);
	}
	free(arr);
}

//Function to decode from data from image  
void decode_image_to_data(char *arr,int size, DecodeInfo *dinfo)
{
	for(int i=0;i<size;i++)
	{
		*(arr+i)=decode_LSB_to_byte(dinfo);
	}
}

//Function to decode LSB's of image to byte
char decode_LSB_to_byte( DecodeInfo *dinfo)
{
	char t,ch=0;
	for(int i=0;i<8;i++)
	{
		fread(&t,1,1,dinfo->fptr_src_image);												//reading data from source file
		t=t&0x01;															//fetching LSB of every Byte
		if(t)
			ch=ch | (1<< (7-i));													//Storing each LSB Bit to form a Byte of data
	}
	return ch;																//return th obtaine Byte from LSB's of 8 Bytes of source file 
}


//Function to decode secret file extension size
int decode_secret_file_extn_size(DecodeInfo *dinfo)
{
	int s=0;
	char t;
	for(int i=0;i<32;i++)
	{
		fread(&t,1,1,dinfo->fptr_src_image);												//reading data from source file
		t=t&0x01;															//fetching LSB of every Byte
		if(t)
			s=s | (1<< (31-i));													//Storing each LSB Bit to form a 4 Bytes(integer) of data
	}
	printf("INFO =>	Secret file extension size is decoded to successfully.\n");
	return s;
}

//Function to decode secret file extension
void decode_secret_file_extn(int s,DecodeInfo *dinfo)
{
	char *arr=malloc(s);
	decode_image_to_data(arr,s,dinfo);													//calling function to decode secret file extension 
	printf("INFO =>	Secret file extension is decoded to successfully.\n");
	if(dinfo->ext == NULL)															//If output file not mentioned
	{
		strcat(defaultn,arr);
		dinfo->fptr_secret = fopen(defaultn, "w");											//Create a default file using decode extension
		printf("INFO =>	Output file not mentioned.Creating %s as default file\n",defaultn);
		printf("opening %s file\n", defaultn);
	}
	else if((strstr(arr,dinfo->ext)) != NULL)											      //comparing decode extension with user mentioned output file extension
	{
		dinfo->fptr_secret = fopen(dinfo->secret_fname, "w");									//opening user mentioned output file
		if (dinfo->fptr_secret == NULL)												//Validation
		{
		  	perror("fopen");
		  	fprintf(stderr, "ERROR :	Provided %s file not found.\n##### DECODING TERMINATED #####\n", dinfo->secret_fname);
		    	exit(0);
		}
		printf("opening %s file\n", dinfo->secret_fname);
	}
	else																	//if extension miss match is found
	{		
		fprintf(stderr, "ERROR :	Provided %s file not matching with encoded secrect file.\n##### DECODING TERMINATED #####\n", dinfo->secret_fname);
		exit(0);
	}
	free(arr);
	printf("*****Opening of all the required files is successful *****\n");
}

//Function to decode secret file size
int decode_secret_file_size(DecodeInfo *dinfo)
{
	int s=0;
	char t;
	for(int i=0;i<32;i++)
	{
		fread(&t,1,1,dinfo->fptr_src_image);												//reading data from source file
		t=t&0x01;															//fetching LSB of every Byte
		if(t)
			s=s | (1<< (31-i));													//Storing each LSB Bit to form a 4 Bytes(integer) of data
	}
	printf("INFO =>	Secret file size is decoded to successfully.\n");
	return s;
	
}
//Function to decode secret file data
void decode_secret_file_data(DecodeInfo *dinfo)
{
	char *arr=malloc(dinfo->size);
	decode_image_to_data(arr,dinfo->size,dinfo);												//reading from source file
	fwrite(arr,1,dinfo->size,dinfo->fptr_secret);												//writing the decoded data to output file
	free(arr);
	printf("INFO =>	Secret file data is decoded to successfully.\n");
}

//Function to perform all decoding operations
void do_decoding(DecodeInfo *dinfo)
{
	printf("##### Starting Decoding Procedure #####\n");											
	fseek(dinfo->fptr_src_image,54,SEEK_SET);												//skipping source filt header Bytes
	decode_magic_string(dinfo);														//Function call to decode magic string
	dinfo->size=decode_secret_file_extn_size(dinfo);											//Function call to decode secret file extension size
	decode_secret_file_extn(dinfo->size,dinfo);												//Function call to decode secret file extension 
	dinfo->size=decode_secret_file_size(dinfo);												//Function call to decode secret file size
	decode_secret_file_data(dinfo);													//Function call to decode secret file data
	printf("******** Secret File is Ready ********\n");
	printf("##### DECODING IS SUCCESSFUL #####\n");
}

