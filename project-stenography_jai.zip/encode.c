//Documentation
//Name           : D. Jaya Krishna
//Date           : 20-04-2022
//Description    : encoding part - lsb steganography
//Input          :
//Output         : 
//Documentation
#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include "types.h"

unsigned int isize,size;

//Function to calculate the size of source image
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    //printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    //printf("height = %u\n", height);

    // Return image capacity
    return (width * height * 3);
}

//Function to check operation(coding) type

int check_operation_type(char *s)
{
	if(*s == 45)															//checking if coding type is mentioned with "-" or not
	{
		if(*(s+1) == 'e')													//checking if coding type is encoding
			return 1;
		else if(*(s+1) == 'd')													//checking if coding type is decoding
			return 0;
		else
		{
			printf("Error:	Enter the correct coding type\n\tIn the format=> ./<filename> -<coding type> <.bmp file> <.txt file> <.bmp file>\n##### ENCODING TERMINATED #####\n\n");
			exit(0);
		}
	}
	else
	{
		printf("Error:	Enter the coding type with \"-\" \n\tIn the format=> ./<filename> -<coding type> <.bmp file> <.txt file> <.bmp file>\n##### ENCODING TERMINATED #####\n\n");
		exit(0);
	}
}


//Function to read and validate command line arguments for encoding
void read_and_validate_encode_args(char *argv[], EncodeInfo *einfo)
{
	
	printf("***** Read and Validate Function in Process *****\n");
	char *checknull;															//a charater pointer to check the file names
	checknull=strstr(argv[2],".bmp");
	if(checknull != NULL)															//if argv[2] is .bmp file
	{
		einfo->src_image_fname=argv[2];
		checknull=strstr(argv[3],".txt");
		if(checknull == NULL)
		{
			checknull=strstr(argv[3],".c");
			einfo->ext=".c";
		}
		else
			einfo->ext=".txt";
		if(checknull != NULL)														//if argv[3] is .txt file
		{
			einfo->secret_fname=argv[3];
			if(argv[4] == NULL)
			{															//for ./a.out -<coding type> <file name> <file name>
				printf("INFO =>	Output file not mentioned.Creating stego.bmp as default\n");
				einfo->stego_image_fname="stego.bmp";										//creating stego_img.bmp file as default output file
			}
			else
			{
				checknull=strstr(argv[4],".bmp");
				if(checknull != NULL)												//if argv[4] is .bmp file
					einfo->stego_image_fname=argv[4];
				else
				{
					printf("Error : Provide output file in .bmp format.\n##### ENCODING TERMINATED #####\n");
					exit(0);
				}
			}
		}
		else
		{
			printf("Error : Provide Secrect text file in .txt or .c format.\n##### ENCODING TERMINATED #####\n");
			exit(0);
		}		
	}
	else		
	{																	//if argv[2] is not .bmp file
		printf("Error : Provide Image file in .bmp format.\n##### ENCODING TERMINATED #####\n");
		exit(0);
	}
	printf("***** Read and Validate Function is Successful *****\n");
}


//Function to open all the required files
void open_files(EncodeInfo *einfo)
{
	printf("*****Opening required files*****\n");
	// Src Image file
	einfo->fptr_src_image = fopen(einfo->src_image_fname, "r");										//opening source file in read mode
	// Do Error handling
	if (einfo->fptr_src_image == NULL)
	{
	   	perror("fopen");
	    	fprintf(stderr, "ERROR: Unable to open file %s.\n##### ENCODING TERMINATED #####\n", einfo->src_image_fname);
	    	exit(0);
	}
	printf("INFO =>	Opening %s file\n", einfo->src_image_fname);

	 // Secret file
	 einfo->fptr_secret = fopen(einfo->secret_fname, "r");										//opening secret file in read mode
	// Do Error handling
	if (einfo->fptr_secret == NULL)
	{
		perror("fopen");
	    	fprintf(stderr, "ERROR: Unable to open file %s.\n##### ENCODING TERMINATED #####\n", einfo->secret_fname);
	    	exit(0);
	}
	printf("INFO =>	Opening %s file\n", einfo->secret_fname);

	// Stego Image file															//opening output file in write mode
	einfo->fptr_stego_image = fopen(einfo->stego_image_fname, "w");
	// Do Error handling
	if (einfo->fptr_stego_image == NULL)
	{
	    	perror("fopen");
	    	fprintf(stderr, "ERROR: Unable to open file %s.\n##### ENCODING TERMINATED #####\n", einfo->stego_image_fname);
	    	exit(0);
	}
	printf("INFO =>	Opening %s file\n",einfo->stego_image_fname);
	printf("*****Opening of all the required files is Successful *****\n");
}


//Function to check_capacity of source file
void check_capacity(EncodeInfo *einfo)
{
	printf("***** Checking  Capacity Procedure in Progress *****\n");
	printf("INFO =>	Checking %s size\n",einfo->src_image_fname);
	isize=get_image_size_for_bmp(einfo->fptr_src_image);
	printf("INFO =>	The %s file size is : %d\n",einfo->src_image_fname,isize);									//printing source file size
	printf("INFO =>	Checking %s size\n",einfo->secret_fname);
	fseek(einfo->fptr_secret, 0L, SEEK_END);
	einfo->ssize=ftell(einfo->fptr_secret);
	if(einfo->ssize>0)																	//checking if secret file is empty or not
	{
		printf("INFO =>	Checking %s size is completed.\n",einfo->secret_fname);
		printf("INFO =>	The %s file size is : %d\n",einfo->secret_fname,einfo->ssize);							//printing secret file size
		printf("INFO =>	Checking for %s capacity to handle %s\n",einfo->src_image_fname,einfo->secret_fname);
		size=166+einfo->ssize;
		if(isize > size)
			printf("INFO =>	%s size is greater than %s.Hence %s can handle %s\n",einfo->src_image_fname,einfo->secret_fname,einfo->src_image_fname,einfo->secret_fname);
		else
		{
			printf("Error :	%s size is greater than %s.Hence %s can not handle %s\n",einfo->secret_fname,einfo->src_image_fname,einfo->src_image_fname,einfo->secret_fname);
			exit(0);
		}
	}
	else
	{
		printf("Error :	Checking %s size is completed.\n\t%s is empty.\n##### ENCODING TERMINATED #####\n",einfo->secret_fname,einfo->secret_fname);
		exit(0);
	}
	printf("***** Checking  Capacity Procedure is Successful *****\n");
}

//Function to data to image
void encode_data_to_image(char *data, int size, FILE *fsrc, FILE *fdes)
{
	char *arr=malloc(8);															//Dynamic memory allocation to store data of source file
	for(int i=0;i<size;i++)
	{
		fread(arr,1,8,fsrc);														//reading source file data and storing
		encode_byte_to_lsb(data[i],arr);												//storing 1Byte(8 Bit) to 8 Byte 
		fwrite(arr,1,8,fdes);		
	}
	free(arr);
}

//Function to encoding 1 Byte of data in LSB's of *byte of data  
void encode_byte_to_lsb(char data, char *image_buffer)
{
	for(int i=0;i<8;i++)															
	{
		*(image_buffer+7-i)=*(image_buffer+7-i)&0xfe;											//clearing LSB of source Byte
		*(image_buffer+7-i)=*(image_buffer+7-i)|((data>>i)&1);									//encoding 1 bit of data in LSB
	}	
}

//Function to encode size to output file
void size_to_image(int ext_size, FILE *fsrc, FILE *fdes,EncodeInfo *einfo)
{
	char *arr=malloc(32),c;														//Dynamic memory allocation to store 32 Bytes of source file
	fread(arr,1,32,fsrc);															//reading and storing 32 Byte from source file
	for(int i=0;i<32;i++)
	{
		c=(char)(ext_size>>i)&1;													//bitwise access of size
		*(arr+31-i)=*(arr+31-i)&0xfe;													//clearing LSB of source Byte
		*(arr+31-i)=*(arr+31-i)|c;													//encoding sccessed size bit of data to LSB
	}
	fwrite(arr,1,32,fdes);		
	free(arr);
}

//Function to copying header of source file to output file
void copy_bmp_header(FILE *fsrc, FILE *fdest)
{
	char *arr=malloc(54);															//Dynamic memory allocation to store header of source file
	rewind(fsrc);
	fread(arr,1,54,fsrc);															//reading from source file
	fwrite(arr,1,54,fdest);														//Writing to output file
	printf("INFO =>	Copying image header is Successfull.\n");
	free(arr);																//freeing Dynamic memory allocation
}

//Function to encoding MAGIC STRING
void encode_magic_string(const char *magic_string, EncodeInfo *einfo)
{
	char ms[2];																//array to store magic string	
	strcpy(ms,magic_string);														//copying magic string to array
	encode_data_to_image(ms,strlen(ms),einfo->fptr_src_image,einfo->fptr_stego_image);							//encoding magic string to output file
	printf("INFO =>	Magic string is encoded to %s Successfully.\n",einfo->stego_image_fname);
	
}

//Function to encode secret file extension size
void encode_secret_file_extn_size(const char *file_extn, EncodeInfo *einfo)
{
	int ext_size=strlen(file_extn);													//calculating string extension length
	size_to_image(ext_size,einfo->fptr_src_image,einfo->fptr_stego_image,einfo);								//Calling size to image function encode size of secret file extension
	printf("INFO =>	secrect file extension size is encoded to %s Successfully.\n",einfo->stego_image_fname);
}

//Function to encode extension of secret file
void encode_secret_file_extn(EncodeInfo *einfo)
{
	encode_data_to_image(einfo->ext,strlen(einfo->ext),einfo->fptr_src_image,einfo->fptr_stego_image);					//calling data to image function to encode secret file extension
	printf("INFO =>	Secret file extension  is encoded to %s successfully.\n",einfo->stego_image_fname);
}

//Function to  Encode secret file size
void encode_secret_file_size(int size, EncodeInfo *einfo)
{
	size_to_image(size,einfo->fptr_src_image,einfo->fptr_stego_image,einfo);								//Calling size to image function to encode size of secret file
	printf("INFO =>	secrect file size is encoded to %s successfully.\n",einfo->stego_image_fname);
}

//Function to  Encode secret file data
void encode_secret_file_data(EncodeInfo *einfo)
{
	char sdata[50];
	rewind(einfo->fptr_secret);														//pointing to start of file
	fread(sdata,1,einfo->ssize,einfo->fptr_secret);											//reading and storing data from secret file
	sdata[einfo->ssize]='\0';														//storing null charater 	
	encode_data_to_image(sdata,einfo->ssize,einfo->fptr_src_image,einfo->fptr_stego_image);						//calling data to image function to encode secret file data
	printf("INFO =>	Secret data is encoded to %s Successfully(and secretly ;) ).\n",einfo->stego_image_fname);
}

//Function to  Copy remaining image bytes from src to stego image after encoding 
void copy_remaining_img_data(EncodeInfo *einfo)
{
	uint l=isize;
	l=l-ftell(einfo->fptr_src_image);						
	char *arr=malloc(l);
	fread(arr,1,l,einfo->fptr_src_image);													//reading remaing data from source file
	fwrite(arr,1,l,einfo->fptr_stego_image);												//writing the remaing data to output file
	printf("INFO =>	Copying remaining image data is Successfull.\n");
	free(arr);	
}
//Function to perform encoding operations
void do_encoding(EncodeInfo *einfo)
{
	printf("##### Starting Encoding Procedure #####\n");
	copy_bmp_header(einfo->fptr_src_image,einfo->fptr_stego_image);						//Function call to copy header from source file to putput file
	encode_magic_string(MAGIC_STRING,einfo);									//Function call to encode MAGIC STRING
	encode_secret_file_extn_size(einfo->ext,einfo);								//Function call to encode secret file extension size
	encode_secret_file_extn(einfo);										//Function call to encode extension of secret file
	encode_secret_file_size(einfo->ssize,einfo);									//Function call to encode secret file size
	encode_secret_file_data(einfo);										//Function call to encode secret file data
	copy_remaining_img_data(einfo);										//Function call to Copy remaining image bytes from src to stego image after encoding
	printf("******* Encoded Image is Ready *******\n");
	printf("##### Encoding is SUCCESSFUL Done #####\n");
}





