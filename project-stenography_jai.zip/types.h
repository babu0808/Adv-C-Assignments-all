#ifndef ENCODE_H
#define ENCODE_H


#define MAGIC_STRING "#*"


typedef struct _EncodeInfo
{
    /* Source Image info */
    char *src_image_fname;
    FILE *fptr_src_image;
    
    /* Secret File Info */
    char *secret_fname;
    FILE *fptr_secret;
    int ssize;

    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;
    
    /*to save extension*/
    char *ext;

} EncodeInfo;


/* ###################################################################Encoding function prototype################################################################3 */

/* Check operation type */
int check_operation_type(char *s);

/* Read and validate Encode args from argv */
void read_and_validate_encode_args(char *argv[], EncodeInfo *einfo);

/* Get File pointers for i/p and o/p files */
void open_files(EncodeInfo *encInfo);

/* check capacity */
void check_capacity(EncodeInfo *encInfo);

/* Perform the encoding */
void do_encoding(EncodeInfo *einfo);

//size to image
void size_to_image(int ext_size, FILE *fsrc, FILE *fdes,EncodeInfo *einfo);

/* Get image size */
uint get_image_size_for_bmp(FILE *fptr_image);

/* Copy bmp image header */
void copy_bmp_header(FILE *fsrc, FILE *fdest);

/* Store Magic String */
void encode_magic_string(const char *magic_string, EncodeInfo *einfo);

/* Encode secret file extenstion size*/
void encode_secret_file_extn_size(const char *file_extn, EncodeInfo *einfo);

/* Encode secret file extenstion */
void encode_secret_file_extn( EncodeInfo *einfo);

/* Encode secret file size */
void encode_secret_file_size(int file_size, EncodeInfo *einfo);

/* Encode secret file data*/
void encode_secret_file_data(EncodeInfo *einfo);

/* Encode function, which does the real encoding */
void encode_data_to_image(char *data, int size, FILE *fsrc, FILE *fdes);

/* Encode a byte into LSB of image data array */
void encode_byte_to_lsb(char data, char *image_buffer);

/* Copy remaining image bytes from src to stego image after encoding */
void copy_remaining_img_data(EncodeInfo *einfo);

#endif
